package com.company;
import java.util.*;

import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.impl.StaticLoggerBinder;


import com.alibaba.fastjson.JSON;
//import org.springframework.stereotype.Component;
public class newLDAP {
    protected static Logger logger = LoggerFactory.getLogger(Main.class);

    private static String LDAP_URL;
    private static String LDAP_URL1;
    public static InitialDirContext ctx;

    public static String userName="uid=pierre.qiu,ou=people,dc=u-psud,dc=fr";
    public static String password="niaiwoma2000/*-";

    //public static String searchBase = "dc=u-psud,dc=fr,ou=people,uid=pierre.qiu";

    public static boolean authenticate(String userName, String password) {
        boolean bRtn = false;// 标注是否验证成功，初始为false
        Hashtable<String, String> env = new Hashtable<String, String>(4);
        // LDAP 服务器的 URL 地址，
        LDAP_URL = "ldaps://ldaps.u-psud.fr/ou=people,dc=u-psud,dc=fr:636";
        LDAP_URL1 = "ldaps://ldaps.u-psud.fr:636";
        //env 中的key都是固定值在 javax.naming.Context 类中
        env.put(Context.INITIAL_CONTEXT_FACTORY,
                "com.sun.jndi.ldap.LdapCtxFactory");// ldapCF
        env.put(Context.PROVIDER_URL, LDAP_URL1);// ldapURL
        env.put(Context.SECURITY_AUTHENTICATION, "simple"); // ldapAuthMode
        //username和对应的password怎么在LDAP服务器中设置，我也不知道
        //通过默认的用户名"cn=manager,dc=aaa,dc=bbb"(aaa、bbb的具体值要在配置文件中配置，具体看参考博文)和密码"secret",可以测试连接是否成功
        env.put(Context.SECURITY_PRINCIPAL, userName);
        env.put(Context.SECURITY_CREDENTIALS, password);
        DirContext ctx = null;

        try {
            //这条代码执行成功就是验证通过了，至于为什么我也不知道
            ctx = new InitialDirContext(env);
            bRtn = true;
            logger.info("Ldap验证通过!");
            logger.info(ctx.getNameInNamespace());
            ArrayList<String> dn = new ArrayList<String>();
            try {

                SearchControls constraints = new SearchControls();
                constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
                String str = "eduPersonAffiliation";

                NamingEnumeration results = ctx.search("ou=people,dc=u-psud,dc=fr", "uid=pierre.qiu", constraints);

                Attributes attrs = ctx.getAttributes("uid=lanshi.fu,ou=people,dc=u-psud,dc=fr");
                System.out.println(attrs.get("cn"));
                System.out.println(attrs.get("eduPersonAffiliation"));
                System.out.println(attrs.get("mail"));
                System.out.println(attrs.get("ou"));
                System.out.println(attrs.get("displayname"));
                System.out.println(attrs.get("givenName"));
                System.out.println(attrs.get("eduPersonPrincipalName"));
                System.out.println(attrs.get("facsimileTelephoneNumber"));
                /*while (results.hasMore()) {facsimileTelephoneNumber
                    NameClassPair nc = (NameClassPair) results.next();
                    System.out.println(nc);
                }*/

            } catch (NamingException e) {
                e.printStackTrace();

            }

        } catch (Exception ex) {
            logger.error("Ldap 初始化 出错:", ex);
        } finally {
            try {
                if (ctx != null) {
                    ctx.close();
                    ctx = null;
                }
                env.clear();
            } catch (Exception e) {
                logger.error("Ldap context close出错:", e);
            }
        }
        if (StringUtils.isBlank(LDAP_URL)) {
            bRtn = true;
        }
        //验证成功返回 true，验证失败返回false
        return bRtn;
    }

    public static void main(String[] args){
        boolean b = authenticate(userName,password);

    }
}
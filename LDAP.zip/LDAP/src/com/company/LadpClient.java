package com.company;

import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;

import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.util.*;

/**
 * @description: LADPClient
 * @author: lizz
 * @date: 2021/8/19 11:04
 */
public class LadpClient {
    // ldap api访问地址
    private final static String ladpUrl = "ldaps://ldaps.u-psud.fr:636/ou=people,dc=u-psud,dc=fr";
    // 访问bindDN
    private final static String bindDN = "uid=lanshi.fu,ou=people,dc=u-psud,dc=fr";
    // 访问密码
    private final static String password = "Lanshi.fu144!";
    // 访问的dn目录
    private final static String dn = "ou=people,dc=u-psud,dc=fr";

    /**
     * 获取用户列表
     */
    public static List<String> userList() {
        DirContext ctx = buildContext();
        Map<String, String> map = new HashMap<>();
        List<String> users = new ArrayList<>();
        try {
            if (ctx != null) {
                NamingEnumeration<NameClassPair> list = ctx.list(dn);
                while (list.hasMore()) {
                    NameClassPair ncp = list.next();
                    String cn = ncp.getName();
                    if (cn.indexOf("=") != -1) {
                        users.add(cn.split("=")[1]);
                    }
                }
            }
        } catch (NamingException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ctx != null) {
                    ctx.close();
                }
            } catch (NamingException e) {
                e.printStackTrace();
            }
        }
        return users;
    }

    /**
     * 条件查询条件查询
     */
   /* public static List<Map<String, Object>> search(String fields, String filter) {
        // 返回信息，相当于select 字段,不能有空格
        if (StringUtils.isEmpty(fields)) {
            fields = "uid,mail";
        }
        // 查询条件，相当于sql中的where
        if (StringUtils.isEmpty(filter)) {
            filter = "(uid=*)";
        }
        DirContext ctx = buildContext();
        List<Map<String, Object>> lm = new ArrayList<>();
        // String[] attrPersonArray = {"*"}; //所有字段
        String[] attrPersonArray = fields.trim().split(",");
        //搜索控件
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(2);//搜索目录范围，2为所有子目录
        searchControls.setReturningAttributes(attrPersonArray);//数据内容
        try {
            if (ctx != null) {
                NamingEnumeration<SearchResult> answer = ctx.search(dn, filter, searchControls);
                while (answer.hasMore()) {
                    SearchResult result = answer.next();
                    NamingEnumeration<? extends Attribute> attrs = result.getAttributes().getAll();
                    Map<String, Object> map1 = new HashMap<>();
                    while (attrs.hasMore()) {
                        Attribute attr = attrs.next();
                        map1.put(attr.getID(), attr.get());
                    }
                    if (map1 != null) {
                        lm.add(map1);
                    }
                }
            }
        } catch (NamingException e) {
            e.printStackTrace();
            return null;
        }
        return lm;
    }
*/
    private static DirContext buildContext() {
        DirContext ctx;
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, ladpUrl);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, bindDN);
        env.put(Context.SECURITY_CREDENTIALS, password);
        try {
            ctx = new InitialDirContext(env);
        } catch (NamingException e) {
            e.printStackTrace();
            return null;
        }
        return ctx;
    }

    public static void main(String[] args) {
        List<String> users = LadpClient.userList();
        System.out.println(JSON.toJSONString(users));
        //List<Map<String, Object>> usersInfo = LadpClient.search("", "");
        //System.out.println(JSON.toJSONString(usersInfo));
    }
}